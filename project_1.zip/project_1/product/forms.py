from django import forms
from . import models
from .models import Products



# Create your forms here.

class Create_product(forms.ModelForm):
    class Meta:
        model = models.Products
        fields = "__all__"
        
        labels = {
            "product_id":"Product ID", 
            "product_name":"Product Name",
            "product_desc":"Product Description",
            "product_price":"Product Price"
        }
        help_texts = {
            "product_id":"Enter Product ID",
            "product_name":"Enter Product Name",
            "product_desc":"Enter Product Description",
            "product_price":"Enter Product Price"
        }
   

class Update_product(forms.ModelForm):
    class Meta:
        model = models.Products
        fields = "__all__"
        
        labels = {
             
            "product_name":"Product Name",
            "product_desc":"Product Description",
            "product_price":"Product Price"
        }
        help_texts = {
            
            "product_name":"Update Product Name",
            "product_desc":"Update Product Description",
            "product_price":"Update Product Price"
        }