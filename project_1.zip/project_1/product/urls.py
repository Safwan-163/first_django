
from django.contrib import admin
from django.urls import path,include
from . import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.display_product,name="home"),
    path("create/",views.create_product,name="create_product"),
    path("display/",views.display_product,name="display_product"),
    path("update/<int:id>",views.update_product,name="update_product"),
    path("delete/<int:id>",views.delete_product,name="delete_product"),
    ]