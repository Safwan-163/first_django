from django.shortcuts import render,redirect

from . import models

from .models import Products
from .forms import Create_product, Update_product  # ← Fixed typo


# Create your views here.

def create_product(request):
    if request.method=="POST":
        form=Create_product(request.POST)
        if form.is_valid():
            form.save()
            return redirect("display_product")
        
    return render(request,"create_product.html")

def display_product(request):
    products = Products.objects.all()
    return render(request,"display_product.html",{"products":products})

def update_product(request,id):
    product = Products.objects.get(pk=id)
    if request.method=="POST":
        form=Update_product(request.POST,instance=product)
        if form.is_valid():
            form.save()
            return redirect("display_product")
    return render(request,"update_product.html",{"product":product})

def delete_product(request,id):
    product = Products.objects.get(pk=id)
    product.delete()
    return redirect("display_product" )
