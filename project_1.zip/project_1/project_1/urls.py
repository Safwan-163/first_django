
from django.contrib import admin
from django.urls import path,include
from django.http import HttpResponse
from . import views
from product import urls as product_urls


urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home,name="home"),
    path('products/', include('product.urls')),
    
]
