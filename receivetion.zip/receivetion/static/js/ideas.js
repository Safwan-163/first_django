const ideaForm = document.getElementById("ideaForm");

ideaForm.addEventListener("submit", function(e){
    e.preventDefault();
    alert("Your magical idea has been sent! 🦉");
    ideaForm.reset();
});