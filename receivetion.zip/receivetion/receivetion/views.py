import os
from django.utils import timezone

from django.shortcuts import redirect, render
from django.core.mail import EmailMessage, send_mail
from django.conf import settings
from django.http import HttpResponse
from receivetion.models import Attendee 

# required import

def home(request):
    return render(request, "index.html")
def register(request):
    return render(request, "register.html")
def events(request):
    return render(request, "events.html")

def gallery(request):
    return render(request, "gellary.html")

def ideas(request):
    return render(request, "idea.html")

def contact(request):
    return render(request, "contacts.html")

def success(request):
    return render(request, "success.html")

def register_user(request):

    if request.method == "POST":

        email = request.POST.get("email")
        name = request.POST.get("name")
        type = request.POST.get("type")
        reg_num = request.POST.get("reg_num")
        password = request.POST.get("password")

        pdf_path = os.path.join(settings.MEDIA_ROOT, "schedule.pdf")

        current_time = timezone.now().strftime("%d %B %Y, %I:%M %p")

        subject = "🎉 Registration Confirmed – Freshers Reception"

        message = f"""
Hello {name},

Thank you for registering for the Freshers' Reception.

📅 Registration Time:
{current_time}
"""

        try:

            # save data
            Attendee.objects.create(
                name=name,
                email=email,
                type=type,
                reg_number=reg_num,
                password=password
            )

            # send email
            email_message = EmailMessage(
                subject,
                message,
                settings.EMAIL_HOST_USER,
                [email],
            )

            email_message.attach_file(pdf_path)
            email_message.send()

            return redirect("success")

        except Exception as e:
            print(e)
            return redirect("register")

    return redirect("register")